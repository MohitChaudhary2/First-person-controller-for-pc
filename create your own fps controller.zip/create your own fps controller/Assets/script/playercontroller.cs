﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playercontroller : MonoBehaviour
{
    public CharacterController controller;
    public float speed = 12f;
    Vector3 Velocity;
    public float jumpheight = 3f;
    public float gravity = -10f;
    public Transform groundCheck;
    public LayerMask groundmask;
    public float groundDistance = 0.2f;
    bool isgrounded;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        isgrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundmask);
        if(isgrounded&&Velocity.y<0)
        {
            Velocity.y = -2f;
        }
        if (isgrounded && Input.GetButtonDown("Jump"))
        {
            Velocity.y = Mathf.Sqrt(jumpheight * -2f * gravity);
        }
        float X = Input.GetAxis("Horizontal");
        float Z = Input.GetAxis("Vertical");
        Vector3 move = transform.right * X + transform.forward * Z;
        controller.Move(move * speed * Time.deltaTime);
        Velocity.y += gravity * Time.deltaTime;
        controller.Move(Velocity * Time.deltaTime);
       
    }
}
